Put your Deployit plugin JARs in this directory.
