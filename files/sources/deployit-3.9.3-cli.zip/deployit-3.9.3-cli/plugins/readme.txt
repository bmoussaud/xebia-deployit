Put your CLI extension jar files in this directory.
